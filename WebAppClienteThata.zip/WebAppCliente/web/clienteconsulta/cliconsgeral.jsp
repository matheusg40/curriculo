<%-- 
    Document   : cliente consulta geral
    Created on : 02 de set. de 2025, 
    Author     : Adilson Lima   
--%>

<%@page import="java.util.List"%>
<%@page import="java.util.ArrayList"%>
<%@page import="model.Cliente"%>
<%@page import="model.DAO.ClienteDAO"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="../css/style.css"/>
        
    </head>
    <body>
        <div class="container">
        <h2>Consulta de Clientes - Geral</h2>
        <%            
            ClienteDAO cliDAO = new ClienteDAO();
            List<Cliente> lst = new ArrayList();         
            lst = cliDAO.consulta_geral();

            int n_reg = 0;
            for (int i=0; i<=lst.size()-1; i++){
                out.println("<br><br>Identificador....: " + lst.get(i).getId());
                out.println("<br>Nome do Cliente: " + lst.get(i).getNome());
                out.println("<br>E-mail.........: " + lst.get(i).getEmail());            
                out.println("<br>Renda..........: " + lst.get(i).getRenda()); 
                n_reg++;
            }
                        
        %>
    
        </div>
        </body>
</html>