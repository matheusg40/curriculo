/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import java.sql.*;
import model.Cliente;
import config.ConectaDB;
import java.util.ArrayList;
import java.util.List;

        
/** @author Adilson Lima
 * Data: 28/08/2025
 * Classe DAO do cliente
 */
public class ClienteDAO {
    // Atrib
    
    //Métodos - CRUD
    public boolean cadastrar( Cliente p_cliente ) throws ClassNotFoundException{
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "Insert INTO clientes (nome, email, renda) VALUES ('"+ p_cliente.getNome() +"', '" +p_cliente.getEmail() + "', " + p_cliente.getRenda() + ")";            
            stmt.executeUpdate(sql); //Insert / Delete / Update
            System.out.println("Registro incluído com sucesso!");
            conn.close();
            return true;
        }catch(SQLException ex){
            return false;
        }        
    }

    public List consulta_geral() throws ClassNotFoundException{
        List lst = new ArrayList();
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            //            select * from clientes
            String sql = "select * from clientes order by nome";  
            ResultSet rs = stmt.executeQuery(sql);
            
            // Apresentar o resultado do "rs"
            int n_reg = 0;
            while (rs.next()){
                Cliente cli = new Cliente();
                cli.setId(Integer.parseInt(rs.getString("pk_id")));
                cli.setNome(rs.getString("nome"));
                cli.setEmail(rs.getString("email"));
                cli.setRenda(Float.parseFloat( rs.getString("renda")) );
                lst.add(cli);                
                //System.out.println(rs.getString("pk_id") + " - " + rs.getString("nome"));
                n_reg++;
            }
            
            conn.close();
            
            if (n_reg == 0){
                return null;
            }else{             
                return lst;
            }            
        }catch(SQLException ex){
            return null;
        }        
    }
    
    public Cliente consulta_id( Cliente cli) throws ClassNotFoundException{        
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            //            SELECT * FROM clientes WHERE pk_id = 2
            String sql = "SELECT * FROM clientes WHERE pk_id = " + cli.getId();  
            ResultSet rs = stmt.executeQuery(sql);
            
            // Apresentar o resultado do "rs"
            int n_reg = 0;
            while (rs.next()){                
                cli.setId(Integer.parseInt(rs.getString("pk_id")));        
                cli.setNome(rs.getString("nome"));
                cli.setEmail(rs.getString("email"));
                cli.setRenda(Float.parseFloat( rs.getString("renda")) );
                n_reg++;
            }            
            conn.close();
            
            if (n_reg == 0){
                return null;
            }else{             
                return cli;
            }            
        }catch(SQLException ex){
            return null;
        }        
    }
    
    public List consulta_nome( String p_nome ) throws ClassNotFoundException{
        List lst = new ArrayList();
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            //            select * from clientes
            String sql = "select * from clientes WHERE nome like '%" + p_nome + "%' order by nome";  
            ResultSet rs = stmt.executeQuery(sql);
            
            // Apresentar o resultado do "rs"
            int n_reg = 0;
            while (rs.next()){
                Cliente cli = new Cliente();                
                cli.setId(Integer.parseInt(rs.getString("pk_id")));                
                cli.setNome(rs.getString("nome"));
                cli.setEmail(rs.getString("email"));
                cli.setRenda(Float.parseFloat( rs.getString("renda")) );
                lst.add(cli);                
                //System.out.println(rs.getString("pk_id") + " - " + rs.getString("nome"));
                n_reg++;
            }            
            conn.close();            
            if (n_reg == 0){
                return null;
            }else{             
                return lst;
            }            
        }catch(SQLException ex){
            return null;
        }        
    }
    
    public boolean excluir( int p_id ) throws ClassNotFoundException{
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "DELETE from clientes WHERE pk_id = " + p_id;            
            stmt.executeUpdate(sql); //Insert / Delete / Update
            System.out.println("Registro excluído com sucesso!");
            conn.close();
            return true;
        }catch(SQLException ex){
            return false;
        }        
    }
    
    public boolean alterar( Cliente p_cliente ) throws ClassNotFoundException{
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();            
            //            UPDATE clientes SET nome = 'Matheus de Souza', email = 'mds@umc.br', renda = 20444 WHERE pk_id = 5;
            String sql = "UPDATE clientes SET nome = '" + p_cliente.getNome() + "', email = '" + p_cliente.getEmail()+ "', renda = " + p_cliente.getRenda() + " WHERE pk_id = " + p_cliente.getId();            
            stmt.executeUpdate(sql); //Insert / Delete / Update
            System.out.println("Registro alterado com sucesso!");
            conn.close();
            return true;
        }catch(SQLException ex){
            return false;
        }        
    }
}
