<%-- 
  Document   : curriculos
    Author     : Matheus e Thais   
--%>

<%@page import="java.util.List"%>
<%@page import="java.util.ArrayList"%>
<%@page import="model.Curriculo"%>
<%@page import="model.DAO.CurriculoDAO"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="../CSS/style.css" rel="stylesheet" type="text/css"/>

        <title>JSP Page</title>
    </head>
    <body>
        <h2>Consulta de Clientes - Geral</h2>
        <%            
            Curriculo csv = new Curriculo();
            CurriculoDAO csvDAO = new CurriculoDAO();
         
           
           csv.setId(Integer.parseInt(request.getParameter("Id")));
           csv = csvDAO.consulta_id(csv);
            
            
            if(csv ==null){
            out.println("<div class='card-curriculo'>");    
            out.print("Cliente não localizado");
            out.println("</div>");
            
            }else{
          
            out.println("<div class='card-curriculo'>");    
            out.println("<p><br><br>Identificador </p>" + csv.getId());
            out.println("<p><br>Nome do Cliente: </p>" + csv.getNome());
            out.println("<p><br>E-mail: </p>" + csv.getEmail());
            out.println("<p><br>Telefone: </p>" + csv.getTelefone());
            out.println("<p><br>Formação: </p>" + csv.getFormacao());
            out.println("<p><br>Experiência: </p>" + csv.getXp());
            out.println("<p><br>Linkedin </p>" + csv.getHabilidades());
            out.println("<p><br>Habilidades: </p>" + csv.getHabilidades());
            out.println("</div>");

            
            }        
        %>
         <a href="../index.html" class="btn-retornar">Retornar ao Menu Principal</a>
    </body>
</html>