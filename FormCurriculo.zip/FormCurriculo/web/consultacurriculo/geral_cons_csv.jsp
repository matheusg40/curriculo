<%-- 
    Document   : curriculos geral
    Author     : Matheus e Thais 
--%>

<%@page import="java.util.List"%>
<%@page import="java.util.ArrayList"%>
<%@page import="model.Curriculo"%>
<%@page import="model.DAO.CurriculoDAO"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="../CSS/style.css" rel="stylesheet" type="text/css"/>

        <title>JSP Page</title>
    </head>
    <body>
      

        <h2>Consulta de Clientes - Geral</h2>
        <%            
            CurriculoDAO csvDAO = new CurriculoDAO();
            List<Curriculo> lst = new ArrayList();         
            lst = csvDAO.consulta_curriculo();

            int n_reg = 0;
            for (int i=0; i<=lst.size()-1; i++){
            out.println("<div class='card-curriculo'>");
            out.println("<h3>Identificador: " + lst.get(i).getId() + "</h3>");
            out.println("<p><strong>Nome Candidato(a):</strong> " + lst.get(i).getNome() + "</p>");
            out.println("<p><strong>E-mail:</strong> " + lst.get(i).getEmail() + "</p>");
            out.println("<p><strong>Telefone:</strong> " + lst.get(i).getTelefone() + "</p>");
            out.println("<p><strong>Formação:</strong> " + lst.get(i).getFormacao() + "</p>");
            out.println("<p><strong>Experiência:</strong> " + lst.get(i).getXp() + "</p>");
            out.println("<p><strong>Habilidades:</strong> " + lst.get(i).getHabilidades() + "</p>");
            out.println("</div>");
            
                n_reg++;
            }
                        
        %><p>
          <a href="../index.html" class="btn-retornar">Retornar ao Menu Principal</a>
    </body>
</html>