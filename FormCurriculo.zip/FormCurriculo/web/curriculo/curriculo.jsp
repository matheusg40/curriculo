<%-- 
  * UNIVERSIDADE MOGI DAS CRUZES 
 * @author Matheus e Thais
--%>
<%@page import="model.Curriculo"%>
<%@page import="model.DAO.CurriculoDAO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="../CSS/style.css" rel="stylesheet" type="text/css"/>

        <title>JSP Page</title>
    </head>
    <body>
        <h2>Controle de Clientes</h2>
        <%
            //Instância do objeto
            Curriculo csv = new Curriculo();

            
            csv.setNome(request.getParameter("nome"));
            csv.setEmail(request.getParameter("email"));
            csv.setTelefone(request.getParameter("telefone"));
            csv.setFormacao(request.getParameter("formacao"));
            csv.setXp(request.getParameter("xp"));
            csv.setLinkedin(request.getParameter("linkedin"));
            csv.setHabilidades(request.getParameter("habilidades")); 
            csv.setPortfolio(request.getParameter("portfolio"));
            csv.setSalario(Float.parseFloat(request.getParameter("salario")));

            

            // Saida
            out.println("<div class='card-curriculo'>");
            out.println("Nome: " + csv.getNome());
            out.println("<p><br>E-mail: </p>" + csv.getEmail());
            out.println("<p><br>Telefone: </p>" + csv.getTelefone());
            out.println("<p><br>Formação: </p>" + csv.getFormacao());
            out.println("<p><br>Experiência: </p>" + csv.getXp());
            out.println("<p><br>Linkedin </p>" + csv.getLinkedin());
            out.println("<p><br>Habilidades </p>" + csv.getHabilidades());
            out.println("<p><br>Portfolio </p>" + csv.getPortfolio());
            out.println("<p><br>Salario </p>" + csv.getSalario());
            out.println("</div>");

            //Salvar
              CurriculoDAO csvDAO = new CurriculoDAO();
                if (csvDAO.cadastrar(csv)) {
            %>
                    <script>
                        alert(" Curriculo inserido com sucesso!");
                    </script>
            <%
                } else {
            %>
                    <script>
                        alert("Infelizmente não conseguimos cadastrar seu curriculo!");
                    </script>
            <%
                }
        %>
        <a href="../index.html" class="btn-retornar">Retornar ao Menu Principal</a>
    </body>
</html>
